X_and_F_symbol_linter <- function() { # nolint: object_name.
}

call(a,
     b)

call(a,
     b = 3)

call(a = 1, b =
       3)

call(a =
       1, b = 3)

call(a = 1,
  b = 3
)

call(
  a = 1,
  b = 3
)

call(
  a =
    1,
  b = 3
)

call(
  a =
    1, b = 3
)

call(
  a =
    1, b =
    3
)

{
    if (TRUE)
3
    else
4
}

{
if (TRUE) {
   3
    } else
4
}

{
if (TRUE)
    3
else {
  4
}
}

{
if (TRUE) {
     3
    } else {
4
}
}

# rather space than brace thing, but
foo <- function(x) {
  if (TRUE) {
    1
  }
  else {
    2
  }
}


if (TRUE) {
  3
} else
  if (FALSE) {
  4
}

if (TRUE) {
  3
} else # comment
  if (FALSE) {
    4
  }

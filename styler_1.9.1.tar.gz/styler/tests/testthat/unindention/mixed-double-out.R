# classical

function(x,
         y) {
  1
}


function(x,
         y,
         k) {
  1
}


function(x,
         y) {
  1
}

function(x,
         y) {
  1
}


function(x, y) {
  1
}

function(x,
         #
         y) {
  1
}


# double
function(
    x,
    y) {
  1
}


function(
    x,
    y,
    k) {
  1
}


function(
    x,
    y) {
  1
}


function(
    x, y) {
  1
}

function(x,
         #
         y) {
  1
}


# last brace
function(
    x, y) {
  NULL
}

function(
    x, y) {
  NULL
}

function(
    x,
    y) {
  NULL
}

function(
    x,
    y) {
  NULL
}

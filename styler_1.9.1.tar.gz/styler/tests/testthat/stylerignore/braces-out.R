x <- function()
3 # styler: off

x<- function() # styler: off
  3


if (x) # styler: off
  3 else
  4

if (x) {
  3
} else  # styler: off
  4

if (x)
  3 else 4 # styler: off

while (x) # styler: off
  "x"


while (x)
  "x"# styler: off

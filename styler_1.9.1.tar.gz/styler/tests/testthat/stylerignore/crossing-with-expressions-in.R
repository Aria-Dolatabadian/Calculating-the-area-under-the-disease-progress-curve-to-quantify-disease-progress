call(
  # styler: off
  1+ 1, test_xkj("hier", na.rm = 3 ,py = 43
  )
)

# also if there are more comments
test_xkj("hier", na.rm = 3, py = 43
         )


x="new" # styler: off
y=1 # none

more_calls(
  # styler: on
  with(
    arguments))
1 + 1
a(!b)

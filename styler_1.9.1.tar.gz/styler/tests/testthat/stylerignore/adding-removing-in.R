# styler: off
1 +1;3
# styler: on
# a comment
c(z )


# styler: off
if (FALSE)
  3
x = 3

y = 2 # comment
# styler: on

if (FALSE) {
  3
}


# styler: off
function()
  NULL
# styler: on


# styler: off
if (f(x)) {
  3
} else
  4
# styler: on


# styler: off
while (x < 4) n()
# styler: on


# styler: off
for(i in 1:3) {
  i
}
# styler: on

# styler: off
for (i in 1:3)
  g(i) - 2

# styler: on
1+ 547809


1 +1 # styler: off

1;1 # styler: off

# styler: off
1 +1;3 # commnet
# styler: on

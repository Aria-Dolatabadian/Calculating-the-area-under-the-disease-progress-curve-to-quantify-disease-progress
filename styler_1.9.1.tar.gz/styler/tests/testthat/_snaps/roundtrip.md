# correct styling does not give an error

    Code
      verify_roundtrip("1+1", "1 + 1")

# corrupt styling does give an error

    The expression evaluated before the styling is not the same as the expression after styling. This should not happen. Please file a bug report on GitHub (https://github.com/r-lib/styler/issues) using a reprex.


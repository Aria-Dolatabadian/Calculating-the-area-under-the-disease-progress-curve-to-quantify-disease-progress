function(a =
      33,
    b
    ) {}

function(a =
      33,
    b) {}

function(a,
    b,
    c
    ) {}

function(a,
    b,
    c) {}

function(ss,
    a =
      3,
    er =
      4
    ) {}

function(a =
           b,
         f =
           d, c =
           3, d =
           4) {

}


# classical
function(a =
           33,
         b
) {}

function(a =
           33,
         b) {}

function(a,
         b,
         c
) {}

function(a,
         b,
         c) {}

function(ss,
         a =
           3,
         er =
           4
) {}

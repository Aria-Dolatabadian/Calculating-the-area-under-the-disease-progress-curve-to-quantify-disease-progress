#' Example
#'
#' @examples
#' 1 + }
NULL

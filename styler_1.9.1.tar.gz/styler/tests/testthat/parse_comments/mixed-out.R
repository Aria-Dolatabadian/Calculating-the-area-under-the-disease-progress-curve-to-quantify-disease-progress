# A file with text
a <- function(x, y, z) {
if (1>10) {
# this is a comment
}
#' another comment
}

#' The bli blauuu2
#'
#' Style code according to the bli blauuu2 guide.
#' @family some
#' @examplesIf TRUE # tab
#' c()
#' @examplesIf TRUE
#' c()
#' @examplesIf TRUE
#' c()
#' @importFrom purrr partial
#' @export
x <- 3


#' Now with needs_rd_emulation
#'
#' Style code according to the bli blauuu2 guide.
#' @family some
#' @examplesIf TRUE # tab
#' a %>% b()
#' @examplesIf TRUE
#' a %>% d()
#' @examplesIf TRUE
#' a %>% c()
#' @importFrom purrr partial
#' @export
x <- 33

#' The bli blauuu2
#'
#' Style code according to the bli blauuu2 guide.
#' @family some
#' @examplesIf TRUE
#' c()
#' @examples
#' x <- 2
#' @importFrom purrr partial
#' @export
x <- 3

#' Some more docs
#'
#' Style code according to the bli blauuu2 guide.
#' @family not
#' @examples
#' x <- 2
#' @examplesIf TRUE
#' c()
#' @export
function() {
  NULL
}

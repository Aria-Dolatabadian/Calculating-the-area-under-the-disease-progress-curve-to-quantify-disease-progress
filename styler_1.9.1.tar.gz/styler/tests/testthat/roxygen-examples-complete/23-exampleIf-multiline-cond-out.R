#' dfalkj fdj
#'
#' fjd;kzj lorem impesum
#' @family xj2lkj
#' @examplesIf {
#'   "this-is-a-cond"
#' }
#' c()
#' @importFrom purrr partial
#' @export
x <- 3


#' dfalkj fdj
#'
#' fjd;kzj lorem impesum
#' @examplesIf {
#'   "this-is-a-cond" %>% c()
#' }
#' c()
x <- 3

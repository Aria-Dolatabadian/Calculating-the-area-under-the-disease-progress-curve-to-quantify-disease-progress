#' this
#'
#' mey
#' @examples
#' 2 + 1
#'
NULL


#' this
#'
#' mey
#' @examples
#' 2 + 1
#'
NULL


#' this
#'
#' mey
#' @examples
#' 2 + 1
NULL



#' this
#'
#' empty line after example
#' @examples
#' 2 + 1
NULL
